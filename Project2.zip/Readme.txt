This project was developed by me using java and I used Eclipse IDE for it's development.
Compile all the programs using jdk 1.8.

Instructions for execution:

Firstly compile the MakeInformationSchema.java
'javac MakeInformationSchema.java'
and run this program
'java MakeInformationSchema'

Thereafter compile all the programs 
'javac CreateTable.java'
'javac DropTable.java'
'javac InsertTable.java'
'javac SelectQuery.java'
'javac SriniBase.java'

and then run the SriniBase.java
'java SriniBase';